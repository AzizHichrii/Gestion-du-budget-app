package Classe;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestConnexion {
    public static void main(String[] args) {
        try {
            Connection conn = Connexion.getConnection();
            System.out.println("Connexion réussie !");

            // Test requête simple
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT version()");
            if(rs.next()) {
                System.out.println("Version MySQL : " + rs.getString(1));
            }

            Connexion.closeConnection();
        } catch (SQLException e) {
            System.err.println("Échec de la connexion :");
            e.printStackTrace();
        }
    }
}